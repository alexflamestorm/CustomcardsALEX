-- Flame Manipulating Fusion
local s,id=GetID()
function s.initial_effect(c)
    -- Activar: Fusion Summon
    local e1=Effect.CreateEffect(c)
    e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_FUSION_SUMMON)
    e1:SetType(EFFECT_TYPE_ACTIVATE)
    e1:SetCode(EVENT_FREE_CHAIN)
    e1:SetCountLimit(1,id)
    e1:SetTarget(s.target)
    e1:SetOperation(s.activate)
    c:RegisterEffect(e1)

    -- GY: Reemplazo de destrucción
    local e2=Effect.CreateEffect(c)
    e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
    e2:SetCode(EFFECT_DESTROY_REPLACE)
    e2:SetRange(LOCATION_GRAVE)
    e2:SetCountLimit(1,{id,1})
    e2:SetTarget(s.reptg)
    e2:SetValue(s.repval)
    e2:SetOperation(s.repop)
    c:RegisterEffect(e2)
end

-- Filtro para Fusions FIRE Warrior
function s.fusionfilter(c)
    return c:IsType(TYPE_FUSION) and c:IsRace(RACE_WARRIOR) and c:IsAttribute(ATTRIBUTE_FIRE)
end

-- Materiales posibles
function s.fcheck(c)
    return c:IsAbleToGrave() and c:IsMonster()
end

function s.materials(c)
    return c:IsAbleToGrave() and c:IsCanBeFusionMaterial()
end

-- Objetivo
function s.target(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then
        return Duel.IsExistingMatchingCard(s.fusionfilter,tp,LOCATION_EXTRA,0,1,nil)
    end
end

-- Activación
function s.activate(e,tp,eg,ep,ev,re,r,rp)
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_CONFIRM)
    local fusion=Duel.SelectMatchingCard(tp,s.fusionfilter,tp,LOCATION_EXTRA,0,1,1,nil):GetFirst()
    if not fusion then return end
    Duel.ConfirmCards(1-tp,fusion)

    local chk_flame = fusion:IsSetCard(0x2d) or fusion:GetCode() == 45231177 or fusion:GetText():lower():find("flame swordsman")

    local mat_locations=LOCATION_HAND+LOCATION_MZONE
    if chk_flame then
        mat_locations=mat_locations+LOCATION_DECK
    end

    local mg=Duel.GetMatchingGroup(s.materials,tp,mat_locations,0,nil)
    local res=Duel.FusionSummon(tp,fusion,nil,mg,nil,SUMMON_TYPE_FUSION)

    if not res then
        Duel.SendtoGrave(fusion,REASON_RULE)
    end
end

-- Reemplazo destrucción
function s.repfilter(c,tp)
    return c:IsFaceup() and c:IsRace(RACE_WARRIOR) and c:IsAttribute(ATTRIBUTE_FIRE)
        and c:IsControler(tp) and c:IsOnField() and not c:IsReason(REASON_REPLACE)
        and (c:IsReason(REASON_BATTLE) or c:IsReason(REASON_EFFECT))
end
function s.reptg(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return eg:IsExists(s.repfilter,1,nil,tp)
        and e:GetHandler():IsAbleToDeck() end
    return Duel.SelectEffectYesNo(tp,e:GetHandler(),96)
end
function s.repval(e,c)
    return s.repfilter(c,e:GetHandlerPlayer())
end
function s.repop(e,tp,eg,ep,ev,re,r,rp)
    Duel.SendtoDeck(e:GetHandler(),nil,SEQ_DECKSHUFFLE,REASON_EFFECT)
end

-- Flamvell Kindling
-- ID: 500000

function c500000.initial_effect(c)
    -- Boost ATK when discarded
    local e1=Effect.CreateEffect(c)
    e1:SetDescription(aux.Stringid(500000,0))
    e1:SetCategory(CATEGORY_ATKCHANGE)
    e1:SetType(EFFECT_TYPE_QUICK_O)
    e1:SetCode(EVENT_FREE_CHAIN)
    e1:SetRange(LOCATION_HAND)
    e1:SetCountLimit(1,500000)
    e1:SetCost(c500000.atkcost)
    e1:SetTarget(c500000.atktg)
    e1:SetOperation(c500000.atkop)
    c:RegisterEffect(e1)

    -- Special Summon if opponent banishes from GY
    local e2=Effect.CreateEffect(c)
    e2:SetDescription(aux.Stringid(500000,1))
    e2:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_DAMAGE)
    e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
    e2:SetCode(EVENT_REMOVE)
    e2:SetRange(LOCATION_GRAVE)
    e2:SetCountLimit(1,500001)
    e2:SetCondition(c500000.spcon)
    e2:SetTarget(c500000.sptg)
    e2:SetOperation(c500000.spop)
    c:RegisterEffect(e2)

    -- Quick Synchro Summon
    local e3=Effect.CreateEffect(c)
    e3:SetDescription(aux.Stringid(500000,2))
    e3:SetType(EFFECT_TYPE_QUICK_O)
    e3:SetCode(EVENT_FREE_CHAIN)
    e3:SetRange(LOCATION_MZONE)
    e3:SetCountLimit(1,500002)
    e3:SetTarget(c500000.syntg)
    e3:SetOperation(c500000.synop)
    c:RegisterEffect(e3)
end

-- Discard Cost for ATK Boost
function c500000.atkcost(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return e:GetHandler():IsDiscardable() end
    Duel.SendtoGrave(e:GetHandler(),REASON_COST+REASON_DISCARD)
end

-- Target for ATK Boost
function c500000.atktg(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return Duel.IsExistingMatchingCard(aux.FilterFaceupFunction(Card.IsSetCard,0x2c),tp,LOCATION_MZONE,0,1,nil) end
end

-- ATK Boost Operation
function c500000.atkop(e,tp,eg,ep,ev,re,r,rp)
    local g=Duel.GetMatchingGroup(aux.FilterFaceupFunction(Card.IsSetCard,0x2c),tp,LOCATION_MZONE,0,nil)
    for tc in aux.Next(g) do
        local e1=Effect.CreateEffect(e:GetHandler())
        e1:SetType(EFFECT_TYPE_SINGLE)
        e1:SetCode(EFFECT_UPDATE_ATTACK)
        e1:SetValue(1200)
        e1:SetReset(RESET_EVENT+RESETS_STANDARD+RESET_PHASE+PHASE_END)
        tc:RegisterEffect(e1)
    end
end

-- Condition for Special Summon
function c500000.spcon(e,tp,eg,ep,ev,re,r,rp)
    return eg:IsExists(Card.IsControler,1,nil,1-tp)
end

-- Target for Special Summon
function c500000.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return e:GetHandler():IsCanBeSpecialSummoned(e,0,tp,false,false) end
    Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,e:GetHandler(),1,0,0)
    Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,400)
end

-- Special Summon Operation
function c500000.spop(e,tp,eg,ep,ev,re,r,rp)
    local c=e:GetHandler()
    if c:IsRelateToEffect(e) then
        Duel.SpecialSummon(c,0,tp,tp,false,false,POS_FACEUP)
        Duel.Damage(1-tp,400,REASON_EFFECT)
    end
end

-- Quick Synchro Summon Target
function c500000.syntg(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return Duel.IsExistingMatchingCard(Card.IsSynchroSummonable,tp,LOCATION_EXTRA,0,1,nil,nil) end
end

-- Quick Synchro Summon Operation
function c500000.synop(e,tp,eg,ep,ev,re,r,rp)
    local g=Duel.GetMatchingGroup(Card.IsSynchroSummonable,tp,LOCATION_EXTRA,0,nil,nil)
    if #g>0 then
        Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
        local sg=g:Select(tp,1,1,nil)
        Duel.SynchroSummon(tp,sg:GetFirst(),nil)
    end
end
"""

# Guardar el script en un archivo
with open(script_path, "w") as file:
    file.write(script_content)

# Devolver la ruta del archivo
script_path


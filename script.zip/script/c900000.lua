-- Flamvell Ignite
local s,id=GetID()
function s.initial_effect(c)
    -- Activación: Buscar o enviar al GY 1 monstruo Pyro con 200 DEF
    local e1=Effect.CreateEffect(c)
    e1:SetCategory(CATEGORY_SEARCH+CATEGORY_TOHAND+CATEGORY_TOGRAVE)
    e1:SetType(EFFECT_TYPE_ACTIVATE)
    e1:SetCode(EVENT_FREE_CHAIN)
    e1:SetCountLimit(1,{id,1})
    e1:SetTarget(s.thtg)
    e1:SetOperation(s.thop)
    c:RegisterEffect(e1)

    -- Efecto continuo: Se activa si un monstruo es Invocado (Normal o Especial)
    local e2=Effect.CreateEffect(c)
    e2:SetCategory(CATEGORY_REMOVE+CATEGORY_DAMAGE)
    e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
    e2:SetCode(EVENT_SUMMON_SUCCESS)
    e2:SetRange(LOCATION_SZONE)
    e2:SetCountLimit(1)
    e2:SetTarget(s.efftg)
    e2:SetOperation(s.effop)
    c:RegisterEffect(e2)
    local e3=e2:Clone()
    e3:SetCode(EVENT_SPSUMMON_SUCCESS)
    c:RegisterEffect(e3)
end

-- Buscar o enviar al GY un monstruo Pyro con 200 DEF
function s.thfilter(c)
    return c:IsRace(RACE_PYRO) and c:IsDefense(200) and (c:IsAbleToHand() or c:IsAbleToGrave())
end
function s.thtg(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return Duel.IsExistingMatchingCard(s.thfilter,tp,LOCATION_DECK,0,1,nil) end
end
function s.thop(e,tp,eg,ep,ev,re,r,rp)
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SELECT)
    local g=Duel.SelectMatchingCard(tp,s.thfilter,tp,LOCATION_DECK,0,1,1,nil)
    if #g>0 then
        local tc=g:GetFirst()
        if tc:IsAbleToHand() and (not tc:IsAbleToGrave() or Duel.SelectOption(tp,aux.Stringid(id,0),aux.Stringid(id,1))==0) then
            Duel.SendtoHand(tc,nil,REASON_EFFECT)
            Duel.ConfirmCards(1-tp,tc)
        else
            Duel.SendtoGrave(tc,REASON_EFFECT)
        end
    end
end

-- Efecto continuo: Aplicar efecto según el tipo del monstruo invocado
function s.efftg(e,tp,eg,ep,ev,re,r,rp,chk)
    local tc=eg:GetFirst()
    if chk==0 then return tc end
end
function s.effop(e,tp,eg,ep,ev,re,r,rp)
    local tc=eg:GetFirst()
    if not tc then return end

    if tc:IsRace(RACE_PYRO) then
        -- Ambos jugadores reciben 500 de daño
        Duel.Damage(tp,500,REASON_EFFECT)
        Duel.Damage(1-tp,500,REASON_EFFECT)
    else
        -- Desterrar cartas del GY del oponente
        local g=Duel.GetMatchingGroup(Card.IsAbleToRemove,tp,0,LOCATION_GRAVE,nil)
        local ct=Duel.GetFieldGroupCount(tp,0,LOCATION_MZONE)+1
        if #g>0 then
            Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
            local sg=g:Select(tp,1,ct,nil)
            Duel.Remove(sg,POS_FACEUP,REASON_EFFECT)
        end
    end
end

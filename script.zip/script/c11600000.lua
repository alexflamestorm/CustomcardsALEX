-- The Phantom Knights of Sabbath Knight
local s,id=GetID()
function s.initial_effect(c)
    -- Xyz Summon alternativa (usando un Rango 4 o menor de "The Phantom Knights" o "Rebellion")
    Xyz.AddProcedure(c,nil,5,2,s.xyzfilter,aux.Stringid(id,0),3)
    c:EnableReviveLimit()

    -- Efecto al ser Invocado: Cambia todos los monstruos a Defensa y reduce su DEF a la mitad
    local e1=Effect.CreateEffect(c)
    e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
    e1:SetCode(EVENT_SPSUMMON_SUCCESS)
    e1:SetCondition(s.defcon)
    e1:SetOperation(s.defop)
    c:RegisterEffect(e1)

    -- Gana efectos según los materiales
    local e2=Effect.CreateEffect(c)
    e2:SetType(EFFECT_TYPE_SINGLE)
    e2:SetCode(EFFECT_MATERIAL_CHECK)
    e2:SetValue(s.matcheck)
    c:RegisterEffect(e2)
end

-- **Filtro para Xyz Summon alternativa**
function s.xyzfilter(c,xyz,tp)
    return c:IsSetCard(0xdb) or c:IsSetCard(0xba) -- "The Phantom Knights" o "Rebellion"
end

-- **Efecto 1: Cambiar a Defensa y reducir DEF**
function s.defcon(e,tp,eg,ep,ev,re,r,rp)
    return e:GetHandler():GetSummonType()==SUMMON_TYPE_XYZ
end
function s.defop(e,tp,eg,ep,ev,re,r,rp)
    local c=e:GetHandler()
    local g=Duel.GetMatchingGroup(Card.IsAttackPos,tp,LOCATION_MZONE,LOCATION_MZONE,c)
    if #g>0 then
        for tc in aux.Next(g) do
            Duel.ChangePosition(tc,POS_FACEUP_DEFENSE)
            -- Reducir DEF a la mitad
            local e1=Effect.CreateEffect(c)
            e1:SetType(EFFECT_TYPE_SINGLE)
            e1:SetCode(EFFECT_SET_DEFENSE_FINAL)
            e1:SetValue(math.ceil(tc:GetDefense()/2))
            e1:SetReset(RESET_EVENT+RESETS_STANDARD)
            tc:RegisterEffect(e1)
        end
    end
end

-- **Efecto 2: Gana efectos según el material**
function s.matcheck(e,c)
    local mat=c:GetMaterial()
    if mat:IsExists(Card.IsSetCard,1,nil,0xdb) then -- "The Phantom Knights" Xyz
        local e1=Effect.CreateEffect(c)
        e1:SetDescription(aux.Stringid(id,1))
        e1:SetType(EFFECT_TYPE_SINGLE)
        e1:SetCode(EFFECT_ATTACK_ALL)
        e1:SetValue(1)
        e1:SetCondition(s.pkcon)
        c:RegisterEffect(e1)
    end
    if mat:IsExists(Card.IsSetCard,1,nil,0xba) then -- "Rebellion" Xyz
        local e2=Effect.CreateEffect(c)
        e2:SetType(EFFECT_TYPE_SINGLE)
        e2:SetCode(EFFECT_PIERCE)
        c:RegisterEffect(e2)
    end
end

-- **Condición para atacar todos los monstruos**
function s.pkcon(e)
    return e:GetHandler():GetOverlayCount()>0
end

